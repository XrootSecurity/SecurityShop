import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertOrderSchema, insertSettingSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Setup multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1E9)}${path.extname(file.originalname)}`;
      cb(null, uniqueName);
    }
  }),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Admin authentication middleware
  const adminAuth = (req: any, res: any, next: any) => {
    const adminId = "73642376721235615341652341652348348746395874987103897238963";
    const adminPassword = "poeuretifewncierufcberutbvyeiurbvrehfnfvdmbvryueryuqmqnmdbwnvdbevhrgueyfuewyuqtuewyqteuwqyr";
    
    const { id, password } = req.body;
    if (id !== adminId || password !== adminPassword) {
      return res.status(401).json({ error: "Unauthorized access" });
    }
    next();
  };

  // Public routes
  
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  // Create order
  app.post("/api/orders", async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      
      // Create or update user session
      let session = await storage.getUserSession(orderData.deviceId);
      if (!session) {
        session = await storage.createUserSession({
          deviceId: orderData.deviceId,
          approvedOrders: [],
        });
      }
      
      res.json(order);
    } catch (error) {
      res.status(400).json({ error: "Invalid order data" });
    }
  });

  // Upload payment proof
  app.post("/api/orders/:id/payment-proof", upload.single("paymentProof"), async (req, res) => {
    try {
      const orderId = req.params.id;
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }
      
      const paymentProofUrl = `/uploads/${req.file.filename}`;
      const order = await storage.updateOrderPaymentProof(orderId, paymentProofUrl);
      
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to upload payment proof" });
    }
  });

  // Get user orders by device ID
  app.get("/api/orders/device/:deviceId", async (req, res) => {
    try {
      const orders = await storage.getOrdersByDeviceId(req.params.deviceId);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Get user session
  app.get("/api/user-session/:deviceId", async (req, res) => {
    try {
      const session = await storage.getUserSession(req.params.deviceId);
      res.json(session || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user session" });
    }
  });

  // Get payment URL setting
  app.get("/api/payment-url", async (req, res) => {
    try {
      const setting = await storage.getSetting("payment_url");
      res.json({ paymentUrl: setting?.value || "" });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch payment URL" });
    }
  });

  // Admin routes

  // Admin login
  app.post("/api/admin/login", adminAuth, async (req, res) => {
    res.json({ success: true, message: "Admin authenticated successfully" });
  });

  // Get all orders (admin)
  app.get("/api/admin/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  // Update order status (admin)
  app.patch("/api/admin/orders/:id/status", async (req, res) => {
    try {
      const { status } = req.body;
      const orderId = req.params.id;
      
      if (!["pending", "approved", "rejected"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const order = await storage.updateOrderStatus(orderId, status);
      
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      
      // If approved, add to user's approved orders
      if (status === "approved") {
        await storage.updateUserApprovedOrders(order.deviceId, orderId);
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ error: "Failed to update order status" });
    }
  });

  // Create product (admin)
  app.post("/api/admin/products", upload.fields([
    { name: "productImage", maxCount: 1 },
    { name: "productFile", maxCount: 1 }
  ]), async (req, res) => {
    try {
      const { name, description, price, fileUrl } = req.body;
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      let imageUrl = null;
      let productFileUrl = fileUrl || null;
      let fileName = null;
      
      if (files.productImage) {
        imageUrl = `/uploads/${files.productImage[0].filename}`;
      }
      
      if (files.productFile) {
        productFileUrl = `/uploads/${files.productFile[0].filename}`;
        fileName = files.productFile[0].originalname;
      }
      
      const productData = insertProductSchema.parse({
        name,
        description,
        price: parseInt(price) * 100, // Convert to cents
        imageUrl,
        fileUrl: productFileUrl,
        fileName,
      });
      
      const product = await storage.createProduct(productData);
      res.json(product);
    } catch (error) {
      res.status(400).json({ error: "Invalid product data" });
    }
  });

  // Delete product (admin)
  app.delete("/api/admin/products/:id", async (req, res) => {
    try {
      const success = await storage.deleteProduct(req.params.id);
      if (success) {
        res.json({ success: true });
      } else {
        res.status(404).json({ error: "Product not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // Update payment URL setting (admin)
  app.post("/api/admin/payment-url", async (req, res) => {
    try {
      const { paymentUrl } = req.body;
      if (!paymentUrl) {
        return res.status(400).json({ error: "Payment URL is required" });
      }
      
      const setting = await storage.setSetting({
        key: "payment_url",
        value: paymentUrl,
      });
      
      res.json(setting);
    } catch (error) {
      res.status(500).json({ error: "Failed to update payment URL" });
    }
  });

  // Serve uploaded files with authorization
  app.use("/uploads", async (req, res) => {
    try {
      // Extract device ID from query params or headers
      const deviceId = req.query.deviceId as string || req.headers['x-device-id'] as string;
      if (!deviceId) {
        return res.status(401).json({ error: "Device ID is required" });
      }

      // Get the file path
      const filePath = path.join(uploadDir, req.path);
      
      // Check if file exists
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: "File not found" });
      }

      // Get the user's session and orders
      const [session, orders] = await Promise.all([
        storage.getUserSession(deviceId),
        storage.getOrdersByDeviceId(deviceId)
      ]);

      if (!session) {
        return res.status(401).json({ error: "Unauthorized access" });
      }

      // Check if the file is a product file that the user has purchased
      const isProductFile = req.path.includes('/products/');
      if (isProductFile) {
        const productId = req.path.split('/').pop()?.split('-')[0];
        const hasAccess = orders.some(order => 
          order.status === 'approved' && 
          order.productIds.includes(productId!)
        );

        if (!hasAccess) {
          return res.status(403).json({ error: "Access to this file is not authorized" });
        }
      }

      // If we get here, the user is authorized to download the file
      res.download(filePath, path.basename(filePath));
    } catch (error) {
      console.error('File download error:', error);
      res.status(500).json({ error: "Failed to process download" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
