import { type Product, type InsertProduct, type Order, type InsertOrder, type UserSession, type InsertUserSession, type Setting, type InsertSetting } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  deleteProduct(id: string): Promise<boolean>;

  // Orders
  getOrders(): Promise<Order[]>;
  getOrdersByDeviceId(deviceId: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;
  updateOrderPaymentProof(id: string, paymentProofUrl: string): Promise<Order | undefined>;

  // User Sessions
  getUserSession(deviceId: string): Promise<UserSession | undefined>;
  createUserSession(session: InsertUserSession): Promise<UserSession>;
  updateUserApprovedOrders(deviceId: string, orderId: string): Promise<UserSession | undefined>;

  // Settings
  getSetting(key: string): Promise<Setting | undefined>;
  setSetting(setting: InsertSetting): Promise<Setting>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private orders: Map<string, Order>;
  private userSessions: Map<string, UserSession>;
  private settings: Map<string, Setting>;

  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.userSessions = new Map();
    this.settings = new Map();
    
    // Initialize with some default products and settings
    this.initializeDefaultProducts();
    this.initializeDefaultSettings();
  }

  private initializeDefaultProducts() {
    const defaultProducts: InsertProduct[] = [
      {
        name: "Advanced Port Scanner",
        description: "Professional network scanning tool with stealth capabilities",
        price: 2500, // $25.00
        imageUrl: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        fileUrl: null,
        fileName: null,
      },
      {
        name: "SQL Injection Toolkit",
        description: "Complete SQL injection testing suite with automated payloads",
        price: 3500, // $35.00
        imageUrl: "https://images.unsplash.com/photo-1516321497487-e288fb19713f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        fileUrl: null,
        fileName: null,
      },
      {
        name: "Wireless Audit Suite",
        description: "Comprehensive wireless network security testing framework",
        price: 4500, // $45.00
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        fileUrl: null,
        fileName: null,
      },
      {
        name: "Payload Generator",
        description: "Automated exploit payload generation system",
        price: 3000, // $30.00
        imageUrl: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        fileUrl: null,
        fileName: null,
      },
    ];

    defaultProducts.forEach(product => {
      const id = randomUUID();
      const fullProduct: Product = {
        ...product,
        id,
        
        createdAt: new Date(),
      };
      this.products.set(id, fullProduct);
    });
  }

  private initializeDefaultSettings() {
    const paymentUrlSetting: Setting = {
      id: randomUUID(),
      key: "payment_url",
      value: "https://example.com/payment", // Default payment URL
      updatedAt: new Date(),
    };
    this.settings.set("payment_url", paymentUrlSetting);
    
    // Add default session timeout (24 hours)
    const sessionTimeoutSetting: Setting = {
      id: randomUUID(),
      key: "session_timeout_hours",
      value: "24",
      updatedAt: new Date(),
    };
    this.settings.set("session_timeout_hours", sessionTimeoutSetting);
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    // Check for duplicate product name
    const existingProduct = Array.from(this.products.values())
      .find(p => p.name.toLowerCase() === insertProduct.name.toLowerCase());
    
    if (existingProduct) {
      throw new Error(`A product with the name "${insertProduct.name}" already exists`);
    }

    // Validate price is positive
    if (insertProduct.price <= 0) {
      throw new Error('Price must be greater than 0');
    }

    const id = randomUUID();
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  // Orders
  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrdersByDeviceId(deviceId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(order => order.deviceId === deviceId);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (order) {
      const updatedOrder = { ...order, status };
      this.orders.set(id, updatedOrder);
      return updatedOrder;
    }
    return undefined;
  }

  async updateOrderPaymentProof(id: string, paymentProofUrl: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (order) {
      const updatedOrder = { ...order, paymentProofUrl };
      this.orders.set(id, updatedOrder);
      return updatedOrder;
    }
    return undefined;
  }

  // User Sessions
  async getUserSession(deviceId: string): Promise<UserSession | undefined> {
    return this.userSessions.get(deviceId);
  }

  async createUserSession(insertSession: InsertUserSession): Promise<UserSession> {
    // Clean up expired sessions first
    await this.cleanupExpiredSessions();

    // Check for existing session
    const existingSession = this.userSessions.get(insertSession.deviceId);
    if (existingSession) {
      // Update existing session
      const updatedSession: UserSession = {
        ...existingSession,
        lastActivity: new Date(),
      };
      this.userSessions.set(insertSession.deviceId, updatedSession);
      return updatedSession;
    }

    // Create new session
    const id = randomUUID();
    const session: UserSession = {
      ...insertSession,
      id,
      lastActivity: new Date(),
      createdAt: new Date(),
      approvedOrders: insertSession.approvedOrders || [],
    };
    this.userSessions.set(insertSession.deviceId, session);
    return session;
  }

  private async cleanupExpiredSessions(): Promise<void> {
    const timeoutHours = parseInt(await this.getSetting('session_timeout_hours')?.then(s => s?.value) || '24');
    const now = new Date();
    
    for (const [deviceId, session] of this.userSessions.entries()) {
      const lastActivity = session.lastActivity;
      const hoursSinceLastActivity = (now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60);
      
      if (hoursSinceLastActivity > timeoutHours) {
        this.userSessions.delete(deviceId);
      }
    }
  }

  async updateUserApprovedOrders(deviceId: string, orderId: string): Promise<UserSession | undefined> {
    const session = this.userSessions.get(deviceId);
    if (session) {
      const updatedApprovedOrders = [...session.approvedOrders, orderId];
      const updatedSession = { 
        ...session, 
        approvedOrders: updatedApprovedOrders,
        lastActivity: new Date(),
      };
      this.userSessions.set(deviceId, updatedSession);
      return updatedSession;
    }
    return undefined;
  }

  // Settings
  async getSetting(key: string): Promise<Setting | undefined> {
    return this.settings.get(key);
  }

  async setSetting(insertSetting: InsertSetting): Promise<Setting> {
    const existingSetting = this.settings.get(insertSetting.key);
    const setting: Setting = {
      id: existingSetting?.id || randomUUID(),
      key: insertSetting.key,
      value: insertSetting.value,
      updatedAt: new Date(),
    };
    this.settings.set(insertSetting.key, setting);
    return setting;
  }
}

export const storage = new MemStorage();
