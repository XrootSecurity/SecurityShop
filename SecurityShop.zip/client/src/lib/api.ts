import { apiRequest } from "./queryClient";

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string;
}

export const api = {
  // Products
  getProducts: () => fetch("/api/products").then(res => res.json()),
  
  // Orders
  createOrder: (orderData: any) => 
    apiRequest("POST", "/api/orders", orderData).then(res => res.json()),
  
  uploadPaymentProof: (orderId: string, file: File) => {
    const formData = new FormData();
    formData.append("paymentProof", file);
    return fetch(`/api/orders/${orderId}/payment-proof`, {
      method: "POST",
      body: formData,
    }).then(res => res.json());
  },
  
  getUserOrders: (deviceId: string) =>
    fetch(`/api/orders/device/${deviceId}`).then(res => res.json()),
  
  getUserSession: (deviceId: string) =>
    fetch(`/api/user-session/${deviceId}`).then(res => res.json()),
  
  getPaymentUrl: () =>
    fetch("/api/payment-url").then(res => res.json()),
  
  // Admin
  adminLogin: (credentials: { id: string; password: string }) =>
    apiRequest("POST", "/api/admin/login", credentials).then(res => res.json()),
  
  getAdminOrders: () =>
    fetch("/api/admin/orders").then(res => res.json()),
  
  updateOrderStatus: (orderId: string, status: string) =>
    apiRequest("PATCH", `/api/admin/orders/${orderId}/status`, { status }).then(res => res.json()),
  
  createProduct: (formData: FormData) =>
    fetch("/api/admin/products", {
      method: "POST",
      body: formData,
    }).then(res => res.json()),
  
  deleteProduct: (productId: string) =>
    apiRequest("DELETE", `/api/admin/products/${productId}`).then(res => res.json()),
  
  updatePaymentUrl: (paymentUrl: string) =>
    apiRequest("POST", "/api/admin/payment-url", { paymentUrl }).then(res => res.json()),
};
