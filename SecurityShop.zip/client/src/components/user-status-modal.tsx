import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, Clock, CheckCircle, XCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { getDeviceId } from "@/lib/device-fingerprint";
import type { Order, Product } from "@shared/schema";
import { useState } from "react";
import { toast } from "@/hooks/use-toast";

interface UserStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserStatusModal({ isOpen, onClose }: UserStatusModalProps) {
  const deviceId = getDeviceId();

  const [downloading, setDownloading] = useState<Record<string, boolean>>({});

  const { data: orders = [], isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders/device", deviceId],
    queryFn: () => api.getUserOrders(deviceId),
    enabled: isOpen,
  });

  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    enabled: isOpen,
  });

  const { data: userSession } = useQuery({
    queryKey: ["/api/user-session", deviceId],
    queryFn: () => api.getUserSession(deviceId),
    enabled: isOpen,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "rejected":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-600 text-white">Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  const canDownload = (orderId: string) => {
    return userSession?.approvedOrders?.includes(orderId) || false;
  };

  const handleDownload = async (orderId: string) => {
    try {
      setDownloading(prev => ({ ...prev, [orderId]: true }));
      
      // Get the order details
      const order = orders.find(o => o.id === orderId);
      if (!order) {
        throw new Error('Order not found');
      }

      // For each product in the order, trigger download
      for (const productId of order.productIds) {
        const product = products.find(p => p.id === productId);
        if (product?.fileUrl) {
          // Create a temporary link to trigger the download
          const link = document.createElement('a');
          link.href = `${product.fileUrl}?deviceId=${encodeURIComponent(deviceId)}`;
          link.download = product.fileName || `product-${productId}.zip`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          
          // Small delay between downloads
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
      
      toast({
        title: 'Download started',
        description: 'Your files are being downloaded.',
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: 'Download failed',
        description: 'There was an error downloading your files. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setDownloading(prev => ({ ...prev, [orderId]: false }));
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-matrix-dark cyber-border max-w-2xl max-h-96 overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-matrix-green">
            ORDER STATUS & DOWNLOADS
          </DialogTitle>
        </DialogHeader>
        
        {isLoading ? (
          <div className="text-center text-matrix-green py-8">
            <div className="animate-pulse">Loading your orders...</div>
          </div>
        ) : orders.length === 0 ? (
          <div className="text-center text-matrix-green/70 py-8">
            No orders found. Make a purchase to see your order status here.
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-matrix-darker p-4 rounded border border-matrix-green/30">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      {getStatusIcon(order.status)}
                      <span className="text-matrix-green font-semibold">
                        Order #{order.id.slice(-8)}
                      </span>
                      {getStatusBadge(order.status)}
                    </div>
                    <p className="text-matrix-green/80 text-sm">
                      <strong>Amount:</strong> ${(order.totalAmount / 100).toFixed(2)}
                    </p>
                    <p className="text-matrix-green/80 text-sm">
                      <strong>Items:</strong> {order.productIds.length} product(s)
                    </p>
                    <p className="text-matrix-green/70 text-xs">
                      <strong>Date:</strong> {new Date(order.createdAt).toLocaleString()}
                    </p>
                  </div>
                  
                  {order.status === "approved" && canDownload(order.id) && (
                    <Button 
                      size="sm" 
                      className="hack-button"
                      onClick={() => handleDownload(order.id)}
                      disabled={downloading[order.id]}
                    >
                      <Download className={`h-4 w-4 mr-1 ${downloading[order.id] ? 'animate-spin' : ''}`} />
                      {downloading[order.id] ? 'Preparing...' : 'Download'}
                    </Button>
                  )}
                </div>
                
                {order.status === "pending" && (
                  <div className="text-sm text-yellow-400 bg-yellow-400/10 p-2 rounded">
                    ⏳ Waiting for admin approval
                  </div>
                )}
                
                {order.status === "approved" && (
                  <div className="text-sm text-green-400 bg-green-400/10 p-2 rounded">
                    ✅ Approved - Downloads available
                  </div>
                )}
                
                {order.status === "rejected" && (
                  <div className="text-sm text-red-400 bg-red-400/10 p-2 rounded">
                    ❌ Payment rejected - Please contact admin
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        <div className="pt-4">
          <Button 
            variant="ghost"
            className="w-full text-matrix-green/70 hover:text-matrix-green"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}