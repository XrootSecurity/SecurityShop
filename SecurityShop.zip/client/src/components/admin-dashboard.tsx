import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LogOut, Plus, Check, X, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { Product, Order } from "@shared/schema";

interface AdminDashboardProps {
  onLogout: () => void;
}

export function AdminDashboard({ onLogout }: AdminDashboardProps) {
  const [productForm, setProductForm] = useState({
    name: "",
    description: "",
    price: "",
    fileUrl: "",
  });
  const [productImage, setProductImage] = useState<File | null>(null);
  const [productFile, setProductFile] = useState<File | null>(null);
  const [paymentUrl, setPaymentUrl] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: products = [] } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const { data: orders = [] } = useQuery<Order[]>({
    queryKey: ["/api/admin/orders"],
    queryFn: api.getAdminOrders,
  });

  const { data: paymentData } = useQuery({
    queryKey: ["/api/payment-url"],
    queryFn: api.getPaymentUrl,
    onSuccess: (data) => {
      setPaymentUrl(data?.paymentUrl || "");
    },
  });

  // Mutations
  const createProductMutation = useMutation({
    mutationFn: (formData: FormData) => api.createProduct(formData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      setProductForm({ name: "", description: "", price: "", fileUrl: "" });
      setProductImage(null);
      setProductFile(null);
      toast({ title: "Product added successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to add product", variant: "destructive" });
    },
  });

  const updateOrderStatusMutation = useMutation({
    mutationFn: ({ orderId, status }: { orderId: string; status: string }) =>
      api.updateOrderStatus(orderId, status),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/orders"] });
      toast({ title: "Order status updated!" });
    },
    onError: () => {
      toast({ title: "Failed to update order status", variant: "destructive" });
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: api.deleteProduct,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      toast({ title: "Product deleted successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to delete product", variant: "destructive" });
    },
  });

  const updatePaymentUrlMutation = useMutation({
    mutationFn: api.updatePaymentUrl,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-url"] });
      toast({ title: "Payment URL updated successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to update payment URL", variant: "destructive" });
    },
  });

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append("name", productForm.name);
    formData.append("description", productForm.description);
    formData.append("price", productForm.price);
    formData.append("fileUrl", productForm.fileUrl);

    if (productImage) {
      formData.append("productImage", productImage);
    }
    if (productFile) {
      formData.append("productFile", productFile);
    }

    createProductMutation.mutate(formData);
  };

  const handlePaymentUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (paymentUrl.trim()) {
      updatePaymentUrlMutation.mutate(paymentUrl.trim());
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-matrix-green text-black">Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">Pending</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-matrix-green font-cyber">
          ADMIN DASHBOARD
        </h2>
        <Button onClick={onLogout} className="hack-button">
          <LogOut className="mr-2 h-4 w-4" />
          LOGOUT
        </Button>
      </div>

      <Tabs defaultValue="products" className="space-y-8">
        <TabsList className="bg-matrix-dark border border-matrix-green/30">
          <TabsTrigger value="products" className="data-[state=active]:bg-matrix-green data-[state=active]:text-black">
            Products
          </TabsTrigger>
          <TabsTrigger value="payments" className="data-[state=active]:bg-matrix-green data-[state=active]:text-black">
            Payments
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-matrix-green data-[state=active]:text-black">
            Users
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-matrix-green data-[state=active]:text-black">
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="products">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Add Product Form */}
            <Card className="cyber-border bg-matrix-dark">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-matrix-green">
                  ADD NEW PRODUCT
                </CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProductSubmit} className="space-y-4">
                  <div>
                    <Label className="text-matrix-green">Product Name:</Label>
                    <Input
                      value={productForm.name}
                      onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label className="text-matrix-green">Price (Rp):</Label>
                    <Input
                      type="number"
                      step="0.01"
                      value={productForm.price}
                      onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                      required
                    />
                  </div>

                  <div>
                    <Label className="text-matrix-green">Description:</Label>
                    <Textarea
                      value={productForm.description}
                      onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                      rows={3}
                      required
                    />
                  </div>

                  <div>
                    <Label className="text-matrix-green">Product Image:</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setProductImage(e.target.files?.[0] || null)}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                    />
                  </div>

                  <div>
                    <Label className="text-matrix-green">Product File:</Label>
                    <Input
                      type="file"
                      onChange={(e) => setProductFile(e.target.files?.[0] || null)}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                    />
                  </div>

                  <div>
                    <Label className="text-matrix-green">File URL (optional):</Label>
                    <Input
                      type="url"
                      value={productForm.fileUrl}
                      onChange={(e) => setProductForm({ ...productForm, fileUrl: e.target.value })}
                      className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-1"
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="hack-button w-full py-3"
                    disabled={createProductMutation.isPending}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    {createProductMutation.isPending ? "ADDING..." : "ADD PRODUCT"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Product List */}
            <Card className="cyber-border bg-matrix-dark">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-matrix-green">
                  PRODUCT INVENTORY ({products.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {products.map((product) => (
                    <div key={product.id} className="bg-matrix-darker p-4 rounded border border-matrix-green/30">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-semibold text-matrix-green">{product.name}</h4>
                          <p className="text-sm text-matrix-green/70 mt-1">{product.description}</p>
                          <p className="text-matrix-green font-bold mt-2">${(product.price / 100).toFixed(2)}</p>
                        </div>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => deleteProductMutation.mutate(product.id)}
                          disabled={deleteProductMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="payments">
          <Card className="cyber-border bg-matrix-dark">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-matrix-green">
                PAYMENT VERIFICATION ({orders.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {orders.map((order) => (
                  <div key={order.id} className="bg-matrix-darker p-4 rounded border border-matrix-green/30">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <p className="text-matrix-green"><strong>Order ID:</strong> #{order.id.slice(-8)}</p>
                        <p className="text-matrix-green"><strong>Device ID:</strong> {order.deviceId}</p>
                        <p className="text-matrix-green"><strong>Amount:</strong> ${(order.totalAmount / 100).toFixed(2)}</p>
                        <p className="text-matrix-green"><strong>Status:</strong> {getStatusBadge(order.status)}</p>
                        <p className="text-matrix-green/70 text-sm"><strong>Created:</strong> {new Date(order.createdAt).toLocaleString()}</p>
                      </div>
                      {order.status === "pending" && (
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            className="hack-button"
                            onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "approved" })}
                            disabled={updateOrderStatusMutation.isPending}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => updateOrderStatusMutation.mutate({ orderId: order.id, status: "rejected" })}
                            disabled={updateOrderStatusMutation.isPending}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                    {order.paymentProofUrl && (
                      <div className="border border-matrix-green/30 rounded p-2">
                        <img 
                          src={order.paymentProofUrl} 
                          alt="Payment Proof" 
                          className="w-full h-32 object-cover rounded"
                        />
                      </div>
                    )}
                  </div>
                ))}
                {orders.length === 0 && (
                  <p className="text-center text-matrix-green/70 py-8">No orders found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card className="cyber-border bg-matrix-dark">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-matrix-green">
                USER MANAGEMENT
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Array.from(new Set(orders.map(order => order.deviceId))).map((deviceId) => {
                  const userOrders = orders.filter(order => order.deviceId === deviceId);
                  const totalSpent = userOrders.reduce((sum, order) => sum + order.totalAmount, 0);
                  const approvedOrders = userOrders.filter(order => order.status === "approved");

                  return (
                    <div key={deviceId} className="bg-matrix-darker p-4 rounded border border-matrix-green/30">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div>
                          <p className="text-matrix-green font-semibold">Device ID:</p>
                          <p className="font-mono text-sm text-matrix-green/80">{deviceId}</p>
                        </div>
                        <div>
                          <p className="text-matrix-green font-semibold">Orders:</p>
                          <p className="text-matrix-green">{userOrders.length}</p>
                        </div>
                        <div>
                          <p className="text-matrix-green font-semibold">Total Spent:</p>
                          <p className="text-matrix-green">${(totalSpent / 100).toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-matrix-green font-semibold">Status:</p>
                          <p className="text-matrix-green">
                            {approvedOrders.length > 0 ? "Active" : "Pending"}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
                {orders.length === 0 && (
                  <p className="text-center text-matrix-green/70 py-8">No users found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card className="cyber-border bg-matrix-dark">
            <CardHeader>
              <CardTitle className="text-xl font-bold text-matrix-green">
                PAYMENT SETTINGS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePaymentUrlSubmit} className="space-y-4">
                <div>
                  <Label className="text-matrix-green">Payment URL (DANA QRIS):</Label>
                  <Input
                    type="url"
                    value={paymentUrl}
                    onChange={(e) => setPaymentUrl(e.target.value)}
                    className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-2"
                    placeholder="https://web.telegram.org/..."
                    required
                  />
                  <p className="text-sm text-matrix-green/70 mt-1">
                    This URL will be used for customer payments. Users will be redirected to this link when they click "Pay Now".
                  </p>
                </div>

                <Button 
                  type="submit" 
                  className="hack-button"
                  disabled={updatePaymentUrlMutation.isPending}
                >
                  {updatePaymentUrlMutation.isPending ? "UPDATING..." : "UPDATE PAYMENT URL"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
