import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart } from "lucide-react";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const price = product.price / 100; // Convert from cents

  return (
    <Card className="cyber-border rounded-lg overflow-hidden scan-line bg-matrix-dark">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={product.imageUrl || "/api/placeholder/800/600"} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-2 text-matrix-green">
          {product.name}
        </h3>
        <p className="text-matrix-green/70 mb-4 text-sm">
          {product.description}
        </p>
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold text-matrix-green">
            ${price}
          </span>
          <Button 
            className="hack-button"
            onClick={() => onAddToCart(product)}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            ADD TO CART
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
