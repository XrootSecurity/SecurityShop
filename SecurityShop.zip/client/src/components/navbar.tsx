import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Shield, Store, ShieldQuestion, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NavbarProps {
  cartItemCount?: number;
  onCartClick?: () => void;
}

export function Navbar({ cartItemCount = 0, onCartClick }: NavbarProps) {
  const [location] = useLocation();

  return (
    <nav className="border-b border-matrix-green/30 backdrop-blur-sm sticky top-0 z-50 bg-matrix-dark/80">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Shield className="text-2xl text-matrix-green animate-pulse-green" />
            <h1 className="text-2xl font-cyber font-bold text-matrix-green animate-glitch">
              SECURITY SHOP
            </h1>
          </div>
          <div className="flex items-center space-x-6">
            <Link href="/">
              <Button 
                className={`hack-button ${location === "/" ? "bg-matrix-green text-black" : ""}`}
                size="sm"
              >
                <Store className="mr-2 h-4 w-4" />
                SHOP
              </Button>
            </Link>
            <Link href="/admin">
              <Button 
                className={`hack-button ${location === "/admin" ? "bg-matrix-green text-black" : ""}`}
                size="sm"
              >
                <ShieldQuestion className="mr-2 h-4 w-4" />
                ADMIN
              </Button>
            </Link>
            {location === "/" && (
              <div className="relative cursor-pointer" onClick={onCartClick}>
                <ShoppingCart className="h-5 w-5 text-matrix-green" />
                {cartItemCount > 0 && (
                  <Badge 
                    className="absolute -top-2 -right-2 bg-hack-red text-white text-xs"
                    variant="destructive"
                  >
                    {cartItemCount}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
