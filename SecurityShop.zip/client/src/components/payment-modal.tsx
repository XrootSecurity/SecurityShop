import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload, ArrowLeft } from "lucide-react";
import type { CartItem } from "@/lib/api";

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBack: () => void;
  cartItems: CartItem[];
  onSubmitPayment: (file: File) => void;
}

export function PaymentModal({ isOpen, onClose, onBack, cartItems, onSubmitPayment }: PaymentModalProps) {
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPaymentProof(e.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (paymentProof) {
      onSubmitPayment(paymentProof);
      setPaymentProof(null);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-matrix-dark cyber-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-matrix-green">
            PAYMENT
          </DialogTitle>
        </DialogHeader>
        
        <div className="text-center space-y-6">
          <p className="text-matrix-green/80">Scan QRIS code to pay with DANA:</p>
          
          <div className="cyber-border rounded-lg p-4 bg-matrix-darker">
            <img 
              src="https://web.telegram.org/87651876-0c1d-4552-9af5-0d1ae7ac847d" 
              alt="QRIS Payment Code" 
              className="w-48 h-48 mx-auto object-contain"
            />
          </div>
          
          <p className="text-sm text-matrix-green/70">
            Total: <span className="font-bold text-matrix-green">${(total / 100).toFixed(2)}</span>
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <Label className="text-matrix-green">Upload Payment Proof:</Label>
            <Input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-2"
            />
          </div>

          <Button 
            className="hack-button w-full py-3"
            onClick={handleSubmit}
            disabled={!paymentProof}
          >
            <Upload className="mr-2 h-4 w-4" />
            SUBMIT PAYMENT PROOF
          </Button>
          
          <Button 
            variant="ghost"
            className="w-full text-matrix-green/70 hover:text-matrix-green"
            onClick={onBack}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
