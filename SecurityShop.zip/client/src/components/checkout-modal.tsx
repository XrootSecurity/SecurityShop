import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { CreditCard } from "lucide-react";
import type { CartItem } from "@/lib/api";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onProceedToPayment: () => void;
}

export function CheckoutModal({ isOpen, onClose, cartItems, onProceedToPayment }: CheckoutModalProps) {
  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-matrix-dark cyber-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-matrix-green">
            CHECKOUT
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="flex justify-between items-center">
              <span className="text-matrix-green">
                {item.name} x{item.quantity}
              </span>
              <span className="text-matrix-green font-semibold">
                ${(item.price * item.quantity / 100).toFixed(2)}
              </span>
            </div>
          ))}
        </div>

        <Separator className="border-matrix-green/30" />
        
        <div className="flex justify-between text-xl font-bold text-matrix-green">
          <span>TOTAL:</span>
          <span>${(total / 100).toFixed(2)}</span>
        </div>

        <div className="space-y-4">
          <Button 
            className="hack-button w-full py-3"
            onClick={onProceedToPayment}
          >
            <CreditCard className="mr-2 h-4 w-4" />
            PROCEED TO PAYMENT
          </Button>
          <Button 
            variant="ghost"
            className="w-full text-matrix-green/70 hover:text-matrix-green"
            onClick={onClose}
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
