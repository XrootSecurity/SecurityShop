import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ExternalLink, Upload, Bell } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { api, type CartItem } from "@/lib/api";

interface SimpleCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onSubmitPayment: (file: File) => void;
  isPending?: boolean;
}

export function SimpleCheckoutModal({ 
  isOpen, 
  onClose, 
  cartItems, 
  onSubmitPayment,
  isPending = false 
}: SimpleCheckoutModalProps) {
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  
  const total = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const { data: paymentData } = useQuery({
    queryKey: ["/api/payment-url"],
    queryFn: api.getPaymentUrl,
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPaymentProof(e.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (paymentProof) {
      onSubmitPayment(paymentProof);
      setPaymentProof(null);
      setShowUpload(false);
    }
  };

  const handlePayNow = () => {
    if (paymentData?.paymentUrl) {
      window.open(paymentData.paymentUrl, '_blank');
      setShowUpload(true);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-matrix-dark cyber-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-matrix-green">
            CHECKOUT
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {cartItems.map((item) => (
            <div key={item.id} className="flex justify-between items-center">
              <span className="text-matrix-green">
                {item.name} x{item.quantity}
              </span>
              <span className="text-matrix-green font-semibold">
                ${(item.price * item.quantity / 100).toFixed(2)}
              </span>
            </div>
          ))}
        </div>

        <Separator className="border-matrix-green/30" />
        
        <div className="flex justify-between text-xl font-bold text-matrix-green">
          <span>TOTAL:</span>
          <span>${(total / 100).toFixed(2)}</span>
        </div>

        {!showUpload ? (
          <div className="space-y-4">
            <Button 
              className="hack-button w-full py-3"
              onClick={handlePayNow}
              disabled={!paymentData?.paymentUrl}
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              PAY NOW
            </Button>
            <Button 
              variant="ghost"
              className="w-full text-matrix-green/70 hover:text-matrix-green"
              onClick={onClose}
            >
              Cancel
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-matrix-darker p-4 rounded border border-matrix-green/30">
              <div className="flex items-center space-x-2 text-matrix-green mb-3">
                <Bell className="h-4 w-4" />
                <span className="text-sm font-semibold">PAYMENT NOTIFICATION</span>
              </div>
              <p className="text-sm text-matrix-green/80 mb-4">
                After completing payment, upload your payment proof screenshot below for admin verification.
              </p>
            </div>

            <div>
              <Label className="text-matrix-green">Upload Payment Proof:</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="bg-matrix-darker border-matrix-green/30 text-matrix-green mt-2"
              />
            </div>

            <Button 
              className="hack-button w-full py-3"
              onClick={handleSubmit}
              disabled={!paymentProof || isPending}
            >
              <Upload className="mr-2 h-4 w-4" />
              {isPending ? "UPLOADING..." : "SUBMIT PAYMENT PROOF"}
            </Button>
            
            <Button 
              variant="ghost"
              className="w-full text-matrix-green/70 hover:text-matrix-green"
              onClick={() => setShowUpload(false)}
            >
              Back
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}