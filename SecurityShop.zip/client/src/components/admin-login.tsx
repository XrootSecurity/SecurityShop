import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface AdminLoginProps {
  onLoginSuccess: () => void;
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [adminId, setAdminId] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();

  const loginMutation = useMutation({
    mutationFn: api.adminLogin,
    onSuccess: () => {
      onLoginSuccess();
      toast({
        title: "ACCESS GRANTED",
        description: "Welcome to the admin dashboard",
      });
    },
    onError: () => {
      toast({
        title: "ACCESS DENIED",
        description: "Invalid credentials",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ id: adminId, password });
  };

  return (
    <div className="max-w-md mx-auto mt-20">
      <Card className="cyber-border bg-matrix-dark">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center text-matrix-green">
            ADMIN ACCESS
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="text-matrix-green">Admin ID:</Label>
              <Input
                type="text"
                value={adminId}
                onChange={(e) => setAdminId(e.target.value)}
                className="bg-matrix-darker border-matrix-green/30 text-matrix-green font-mono mt-2"
                placeholder="Enter admin ID"
                required
              />
            </div>
            
            <div>
              <Label className="text-matrix-green">Password:</Label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-matrix-darker border-matrix-green/30 text-matrix-green font-mono mt-2"
                placeholder="Enter password"
                required
              />
            </div>

            <Button 
              type="submit"
              className="hack-button w-full py-3"
              disabled={loginMutation.isPending}
            >
              <LogIn className="mr-2 h-4 w-4" />
              {loginMutation.isPending ? "ACCESSING..." : "ACCESS SYSTEM"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
