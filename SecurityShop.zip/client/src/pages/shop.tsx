import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Code, Shield, FileCode, User, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProductCard } from "@/components/product-card";
import { SimpleCheckoutModal } from "@/components/simple-checkout-modal";
import { UserStatusModal } from "@/components/user-status-modal";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { api, type CartItem } from "@/lib/api";
import { getDeviceId } from "@/lib/device-fingerprint";
import type { Product } from "@shared/schema";

export default function Shop() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [showUserStatus, setShowUserStatus] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<any>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
    queryFn: api.getProducts,
  });

  // Mutations
  const createOrderMutation = useMutation({
    mutationFn: api.createOrder,
    onSuccess: (order) => {
      setCurrentOrder(order);
      setShowCheckout(true);
      toast({
        title: "Order created successfully!",
        description: "Please complete payment and upload proof.",
      });
    },
    onError: () => {
      toast({
        title: "Failed to create order",
        variant: "destructive",
      });
    },
  });

  const uploadPaymentMutation = useMutation({
    mutationFn: ({ orderId, file }: { orderId: string; file: File }) =>
      api.uploadPaymentProof(orderId, file),
    onSuccess: () => {
      toast({
        title: "Payment proof uploaded successfully!",
        description: "Please wait for admin approval.",
      });
      setShowPayment(false);
      setCart([]);
      setCurrentOrder(null);
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
    onError: () => {
      toast({
        title: "Failed to upload payment proof",
        variant: "destructive",
      });
    },
  });

  const addToCart = (product: Product) => {
    setCart(currentCart => {
      const existingItem = currentCart.find(item => item.id === product.id);
      if (existingItem) {
        return currentCart.map(item =>
          item.id === product.id 
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...currentCart, {
          id: product.id,
          name: product.name,
          price: product.price,
          quantity: 1,
          imageUrl: product.imageUrl || undefined,
        }];
      }
    });

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleCheckout = () => {
    if (cart.length > 0) {
      const deviceId = getDeviceId();
      const productIds = cart.flatMap(item => 
        Array(item.quantity).fill(item.id)
      );
      const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

      createOrderMutation.mutate({
        deviceId,
        productIds,
        totalAmount,
        status: "pending",
        paymentProofUrl: null,
      });
    }
  };

  const handleSubmitPayment = (file: File) => {
    if (currentOrder) {
      uploadPaymentMutation.mutate({ orderId: currentOrder.id, file });
    }
  };

  const handleCartClick = () => {
    if (cart.length > 0) {
      handleCheckout();
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-matrix-darker text-matrix-green font-mono">
        <nav className="border-b border-matrix-green/30 backdrop-blur-sm sticky top-0 z-50 bg-matrix-dark/80">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <Shield className="text-2xl text-matrix-green animate-pulse-green" />
                <h1 className="text-2xl font-cyber font-bold text-matrix-green animate-glitch">
                  SECURITY SHOP
                </h1>
              </div>
              <div className="flex items-center space-x-4">
                <Button 
                  className="hack-button"
                  size="sm"
                  onClick={() => setShowUserStatus(true)}
                >
                  <User className="mr-2 h-4 w-4" />
                  MY ORDERS
                </Button>
                <div className="relative cursor-pointer" onClick={handleCartClick}>
                  <ShoppingCart className="h-5 w-5 text-matrix-green" />
                  {cartItemCount > 0 && (
                    <Badge 
                      className="absolute -top-2 -right-2 bg-hack-red text-white text-xs"
                      variant="destructive"
                    >
                      {cartItemCount}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>
        </nav>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-matrix-green">
            <div className="animate-pulse">Loading products...</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-matrix-darker text-matrix-green font-mono">
      <nav className="border-b border-matrix-green/30 backdrop-blur-sm sticky top-0 z-50 bg-matrix-dark/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Shield className="text-2xl text-matrix-green animate-pulse-green" />
              <h1 className="text-2xl font-cyber font-bold text-matrix-green animate-glitch">
                SECURITY SHOP
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                className="hack-button"
                size="sm"
                onClick={() => setShowUserStatus(true)}
              >
                <User className="mr-2 h-4 w-4" />
                MY ORDERS
              </Button>
              <div className="relative cursor-pointer" onClick={handleCartClick}>
                <ShoppingCart className="h-5 w-5 text-matrix-green" />
                {cartItemCount > 0 && (
                  <Badge 
                    className="absolute -top-2 -right-2 bg-hack-red text-white text-xs"
                    variant="destructive"
                  >
                    {cartItemCount}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </nav>
      
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12 scan-line">
          <div 
            className="relative h-64 bg-cover bg-center rounded-lg cyber-border mb-8"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400')`
            }}
          >
            <div className="absolute inset-0 bg-black/70 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <h2 className="text-4xl font-cyber font-bold mb-4 animate-glitch text-matrix-green">
                  DIGITAL SECURITY ARSENAL
                </h2>
                <p className="text-lg text-matrix-green/80">
                  Advanced Scripts • Security Tools • Digital Assets
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="cyber-border bg-matrix-dark scan-line">
            <CardContent className="pt-6">
              <Code className="text-3xl text-matrix-green mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-matrix-green">Security Scripts</h3>
              <p className="text-matrix-green/70">
                Advanced penetration testing and security automation scripts
              </p>
            </CardContent>
          </Card>
          
          <Card className="cyber-border bg-matrix-dark scan-line">
            <CardContent className="pt-6">
              <Shield className="text-3xl text-matrix-green mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-matrix-green">Hacking Tools</h3>
              <p className="text-matrix-green/70">
                Professional-grade security testing and analysis tools
              </p>
            </CardContent>
          </Card>
          
          <Card className="cyber-border bg-matrix-dark scan-line">
            <CardContent className="pt-6">
              <FileCode className="text-3xl text-matrix-green mb-4" />
              <h3 className="text-xl font-semibold mb-2 text-matrix-green">Digital Assets</h3>
              <p className="text-matrix-green/70">
                Exclusive files, templates, and digital resources
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={addToCart}
            />
          ))}
        </div>

        {products.length === 0 && (
          <div className="text-center py-12">
            <p className="text-matrix-green/70 text-lg">No products available at the moment.</p>
          </div>
        )}
      </div>

      {/* Modals */}
      <SimpleCheckoutModal
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        cartItems={cart}
        onSubmitPayment={handleSubmitPayment}
        isPending={uploadPaymentMutation.isPending}
      />

      <UserStatusModal
        isOpen={showUserStatus}
        onClose={() => setShowUserStatus(false)}
      />
    </div>
  );
}
